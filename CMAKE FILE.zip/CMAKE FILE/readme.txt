sudo apt-get update
sudo apt-get cmake


go into cmake folder
where cmake file has : build and source

then:
      cmake ..

It should find everything

make by using the make command to generate the executable
from there you can run
the program by

./#program
